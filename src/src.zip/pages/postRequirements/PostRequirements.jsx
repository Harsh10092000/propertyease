import Footer from "../../components/footer/Footer";
import Navbar from "../../components/navbar/Navbar";
import { TextField } from "@mui/material";
const PostRequirements = () => {
  return (
    <div>
      <Navbar />
      <div>
        <h1 className="text-align-center">Post Requirements</h1>
      </div>
    </div>
  );
};

export default PostRequirements;
